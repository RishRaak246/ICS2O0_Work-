inFH=open("resources/plainMessage.txt","r")
#outFH=open("resources/encodedMessage.txt","wb")
while True:
  inChar = inFH.read(1)
  if inChar=="":
    break
  if inChar=="a":
    codedNum="s"
  elif inChar=="b":
    codedNum="i"
  elif inChar=="c":
    codedNum="l"
  elif inChar=="d":
    codedNum="D"
  elif inChar=="e":
    codedNum="6"
  elif inChar=="f":
    codedNum="f"
  elif inChar=="g":
    codedNum="j"
  elif inChar=="h":
    codedNum="p"
  elif inChar=="i":
    codedNum="9"
  elif inChar=="j":
    codedNum="8"
  elif inChar=="k":
    codedNum="Q"
  elif inChar=="l":
    codedNum="O"
  elif inChar=="m":
    codedNum="y"
  elif inChar=="n":
    codedNum="u"
  elif inChar=="o":
    codedNum="5"
  elif inChar=="p":
    codedNum="m"
  elif inChar=="q":
    codedNum="e"
  elif inChar=="r":
    codedNum="a"
  elif inChar=="s":
    codedNum="A"
  elif inChar=="t":
    codedNum="3"
  elif inChar=="u":
    codedNum="X"
  elif inChar=="v":
    codedNum="B"
  elif inChar=="w":
    codedNum="Y"
  elif inChar=="x":
    codedNum="1"
  elif inChar=="y":
    codedNum="o"
  elif inChar=="z":
    codedNum="b"
  elif inChar=="A":
    codedNum="S"
  elif inChar=="B":
    codedNum="r"
  elif inChar=="C":
    codedNum="K"
  elif inChar=="D":
    codedNum="U"
  elif inChar=="E":
    codedNum="R"
  elif inChar=="F":
    codedNum="c"
  elif inChar=="G":
    codedNum="N"
  elif inChar=="H":
    codedNum="J"
  elif inChar=="I":
    codedNum="W"
  elif inChar=="J":
    codedNum="d"
  elif inChar=="K":
    codedNum="7"
  elif inChar=="L":
    codedNum="n"
  elif inChar=="M":
    codedNum="4"
  elif inChar=="N":
    codedNum="0"
  elif inChar=="O":
    codedNum="q"
  elif inChar=="P":
    codedNum="x"
  elif inChar=="Q":
    codedNum="w"
  elif inChar=="R":
    codedNum="2"
  elif inChar=="S":
    codedNum="L"
  elif inChar=="T":
    codedNum="t"
  elif inChar=="U":
    codedNum="V"
  elif inChar=="V":
    codedNum="k"
  elif inChar=="W":
    codedNum="z"
  elif inChar=="X":
    codedNum="F"
  elif inChar=="Y":
    codedNum="I"
  elif inChar=="Z":
    codedNum="Z"
  elif inChar=="0":
    codedNum="E"
  elif inChar=="1":
    codedNum="T"
  elif inChar=="2":
    codedNum="C"
  elif inChar=="3":
    codedNum="v"
  elif inChar=="4":
    codedNum="G"
  elif inChar=="5":
    codedNum="M"
  elif inChar=="6":
    codedNum="g"
  elif inChar=="7":
    codedNum="H"
  elif inChar=="8":
    codedNum="h"
  elif inChar=="9":
    codedNum="B"
  #asciiNum = ord(inChar)
  ##
  ## Simple Encoding - Multiply by 12
  ##
  #codedNum = asciiNum * 12
  ## 
  print(codedNum)
  #outFH.write(codedNum)
#outFH.close()